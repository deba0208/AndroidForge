# Picnic Manager — Android 9+

A native Kotlin Android app for offline picnic budgeting and expense tracking. Minimum Android version: Android 9 / API 28.

## Features in this version
- Dashboard: budget target, collected contributions, expense total, remaining balance and counts.
- People: add/edit/delete participant and contribution.
- Expenses: item name, quantity, unit, unit price, line total and payer.
- Preloaded shopping-list template for the 9-person picnic menu. Select the items to add; quantities are prefilled and unit prices default to zero until edited.
- Bengali / English UI toggle (language is persisted).
- Settlement estimate: each person's contribution and payer-tagged purchases are compared with an equal share of expenses. Positive net is a credit; negative net is due. This is an estimate and assumes all contributions and payer-tagged expenses should be reconciled against equal shares.
- Share a text report through Android share sheet (WhatsApp, email, etc.).
- New picnic/reset clears local people and items; asks for confirmation.
- SQLite persistence; works offline.

## Build APK
1. Open this project folder in Android Studio.
2. Allow Gradle sync; first sync requires internet to download Gradle/Android Gradle Plugin.
3. Install Android SDK Platform 35 if prompted.
4. Build > Build APK(s).
5. Debug APK path: `app/build/outputs/apk/debug/app-debug.apk`.

The project uses Android API 28 minimum, so it supports Android 9 and newer.
